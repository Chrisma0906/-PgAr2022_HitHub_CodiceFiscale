package it.unibs.fp.codicefiscale;

public class Persona {
		private String id;
		private String nome;
		private String cognome;
		private String sesso;
		private String comune_nascita;
		private String data_nascita;
		private CodFiscale cf;
		
		public Persona(){};
		
		public Persona(String id,String nome, String cognome, String sesso, String dataNascita, String luogoNascita) {
			super();
			this.id = id;
			this.nome = nome;
			this.cognome = cognome;
			this.sesso = sesso;
			this.data_nascita = dataNascita;
			this.comune_nascita = luogoNascita;
			//this.cf = new CodFiscale(nome);
			this.cf = new CodFiscale(nome, cognome, sesso, dataNascita, luogoNascita);
		}
		
		public Persona(String id,String nome, String cognome, String sesso, String dataNascita, String luogoNascita,CodFiscale cf) {
			super();
			this.id = id;
			this.nome = nome;
			this.cognome = cognome;
			this.sesso = sesso;
			this.data_nascita = dataNascita;
			this.comune_nascita = luogoNascita;
			//this.cf = new CodFiscale(nome);
			this.cf = cf;
		}
		
		public String getCodiceFisc() {
			return cf.getCodFiscale();
		}
		
		public void setCodiceFisc(String cof) {
			cf.setCodFiscale(cof);
		}
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public String getCognome() {
			return cognome;
		}
		public void setCognome(String cognome) {
			this.cognome = cognome;
		}
		public String getSesso() {
			return sesso;
		}
		public void setSesso(String sesso) {
			this.sesso = sesso;
		}
		public String getDataNascita() {
			return data_nascita;
		}
		public void setDataNascita(String dataNascita) {
			this.data_nascita = dataNascita;
		}
		
		public String getLuogoNascita() {
			return comune_nascita;
		}
		
		public String getCf() {
			return cf.toString();
		}
		
		public void setCf() {
			this.cf = new CodFiscale(nome, cognome, sesso, data_nascita, comune_nascita);
		}
		
		
		
		public void setLuogoNascita(String luogoNascita) {
			this.comune_nascita = luogoNascita;
		}

		public String toString() {
			return "Id: " + id + "\nNome: " + nome + "\nCognome: " + cognome + "\nSesso: " + sesso
					+ "\nComune di nascita: " + comune_nascita + "\nData di nascita: " + data_nascita + cf.toString() ;
		}	
		
		
	}
