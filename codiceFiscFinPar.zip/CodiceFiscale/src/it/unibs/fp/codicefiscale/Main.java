package it.unibs.fp.codicefiscale;

import java.io.*;
import java.util.*;

import javax.xml.stream.*;

public class Main {

	public static void main(String[] args)  {
		String file1="inputPersone.xml", file2="codiciFiscali.xml",file3="CodiciPersone.xml";
		
		ArrayList<Persona>elenco = new ArrayList<Persona>();
		ArrayList<CodFiscale>codici = new ArrayList<CodFiscale>();
		ArrayList<String> invalidi=new ArrayList<String>();
		ArrayList<String> spaiati=new ArrayList<String>();
		ArrayList<String> daControllare=new ArrayList<String>();
		ArrayList<Persona> validi=new ArrayList<Persona>();
		int flag=0;
		elenco=creaPersone(file1);
		codici=leggiCodiciFisc(file2);
		
		
		//0=false,1=true
		for(int i=0;i<elenco.size();i++) {
			for(int j=0;j<codici.size();j++) {
				if(elenco.get(i).toString().equals(codici.get(j).toString())) {
					
					flag=0;
					break;
				}else {
					flag=1;
				}
				if(flag==1) {
					elenco.get(i).setCodiceFisc("ASSENTE");
				}
				flag=0;
			}
			
			
		}
		
		
		for(int i=0;i<elenco.size();i++) {
			System.out.println(elenco.get(i).toString()+"\n-------------");
		}
		
		//codici invalidi
		for(int i=0;i<codici.size();i++) {
			if(!codVero(codici.get(i).getCodFiscale())){
				invalidi.add(codici.get(i).getCodFiscale());
			}
		}
		
		for(int i=0;i<elenco.size();i++) {
			daControllare.add(elenco.get(i).getCodiceFisc());
		}
		
		for(int i=0;i<codici.size();i++) {
			spaiati.add(codici.get(i).getCodFiscale());
		}
		
		spaiati.removeAll(invalidi);
		spaiati.removeAll(daControllare);
		
		
		/*
		for(int i=0; i<codici.size(); i++){
			if(codVero(codici.get(i).getCodFiscale())){
				for(int j=0; j<elenco.size(); j++){
					if(elenco.get(j).getCodiceFisc().equals(codici.get(i).getCodFiscale())){
						validi.add(elenco.get(j).getCodiceFisc());
					}else{
						//spaiati.add(elenco.get(j).getCodiceFisc());
						//spaiati.add(codici.get(i).getCodFiscale());
					}
				}
			}else{   
				invalidi.add(codici.get(i).getCodFiscale());
			}
		}*/
		
		
		
		
		XMLOutputFactory xmlof = null;
		XMLStreamWriter xmlw = null;
		try {
		xmlof = XMLOutputFactory.newInstance();
		xmlw = xmlof.createXMLStreamWriter(new FileOutputStream(file3), "utf-8");
		xmlw.writeStartDocument("utf-8", "1.0");
		} catch (Exception e) {
		System.out.println("Errore nell'inizializzazione del writer:");
		System.out.println(e.getMessage());
		}
		
		String numero="";
	/*
		try { // blocco try per raccogliere eccezioni
		xmlw.writeStartElement("output"); // scrittura del tag radice <programmaArnaldo>
		xmlw.writeStartElement("persone");
		xmlw.writeAttribute("numero", ""+elenco.size() );
		
		
		for(int i=0; i<codici.size(); i++){
			if(codVero(codici.get(i).getCodFiscale())){
				for(int j=0; j<elenco.size(); j++){
					if(elenco.get(j).getCodiceFisc().equals(codici.get(i).getCodFiscale())){
						xmlw.writeStartElement("persona");
						xmlw.writeAttribute("id", elenco.get(j).getId() );
						xmlw.writeStartElement("nome");
						xmlw.writeCharacters(elenco.get(j).getNome());
						xmlw.writeEndElement();
						xmlw.writeStartElement("cognome");
						xmlw.writeCharacters(elenco.get(j).getCognome());
						xmlw.writeEndElement();
						xmlw.writeStartElement("sesso");
						xmlw.writeCharacters(elenco.get(j).getSesso());
						xmlw.writeEndElement();
						xmlw.writeStartElement("comune_nascita");
						xmlw.writeCharacters(elenco.get(j).getLuogoNascita());
						xmlw.writeEndElement();
						xmlw.writeStartElement("data_nascita");
						xmlw.writeCharacters(elenco.get(j).getDataNascita());
						xmlw.writeEndElement();
						xmlw.writeStartElement("codice_fiscale");
						xmlw.writeCharacters(elenco.get(j).getCodiceFisc());
						xmlw.writeEndElement();
						xmlw.writeEndElement();
					}else{
					}
				}
			}/*else{   
				invalidi.add(codici.get(i).getCodFiscale());
			}
		}
		
		xmlw.writeEndElement();
		xmlw.writeEndElement();
		xmlw.writeEndDocument(); // scrittura della fine del documento
		xmlw.flush(); // svuota il buffer e procede alla scrittura
		xmlw.close();

		} catch (Exception e) { // se c�� un errore viene eseguita questa parte
		System.out.println("Errore nella scrittura");
		}*/
		
		
		
		
		System.out.println("Codici validi: "+validi.size());
		/*
		for(int i=0;i<validi.size();i++) {
			if(validi.get(i).toString().equals("LRCDMN03A06D988B")) {
				System.out.println("sesso");
			}
		}*/
		
		
		System.out.println("Codici invalidi: "+invalidi.size());
		/*
		for(int i=0;i<invalidi.size();i++) {
			System.out.println(invalidi.get(i).toString());
		}*/
		
		System.out.println("Codici spaiati: "+spaiati.size());
		/*
		for(int i=0;i<spaiati.size();i++) {
			System.out.println(spaiati.get(i).toString());
		}*/
		
	}
	
	private static boolean codVero(String codFiscale) {
		int i,j;
		for(i=0; i<6; i++){
			if(codFiscale.charAt(i)<'A' || codFiscale.charAt(i)>'Z'){
				return false;
			}
		}
		
		for(j=i; i<j+2; i++){
			if(codFiscale.charAt(i)<'0' || codFiscale.charAt(i)>'9'){
				return false;
			}
		}
		
		j+=2;
		
		if(codFiscale.charAt(i)<'A' || codFiscale.charAt(i)>'Z'){
			return false;
		}
		
		i++;
		j++;
		
		for(j=i; i<j+2; i++){
			if(codFiscale.charAt(i)<'0' || codFiscale.charAt(i)>'9'){
				return false;
			}
		}
		
		j+=2;
		
		if(codFiscale.charAt(i)<'A' || codFiscale.charAt(i)>'Z'){
			return false;
		}
		
		i++;
		j++;
		
		for(j=i; i<j+3; i++){
			if(codFiscale.charAt(i)<'0' || codFiscale.charAt(i)>'9'){
				return false;
			}
		}
		j+=3;
		if(codFiscale.charAt(i)<'A' || codFiscale.charAt(i)>'Z'){
			return false;
		}
		return true;
	}
	
	public static ArrayList<Persona> creaPersone(String filename) {
		String tagCorrente="";
		ArrayList<Persona>elenco = new ArrayList<Persona>();
		
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader(filename, new FileInputStream(filename));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
		try {
			while (xmlr.hasNext()){ 
				
				switch (xmlr.getEventType()) { 
					case XMLStreamConstants.START_DOCUMENT: 
						System.out.println("Start Read Doc " + filename); 
						System.out.println("\nCaricamento in corso..."); 
					break;
					
					case XMLStreamConstants.START_ELEMENT: 
						
						if(xmlr.getLocalName().equals("persona")) {
							elenco.add(new Persona());
						}
						tagCorrente=xmlr.getLocalName();
						
						for (int i = 0; i < xmlr.getAttributeCount(); i++) {
							if(xmlr.getAttributeLocalName(i).equals("id")) {
								elenco.get(elenco.size()-1).setId(xmlr.getAttributeValue(i));
							}
						}
					break;
					case XMLStreamConstants.END_ELEMENT:
					break;
					
					case XMLStreamConstants.COMMENT:	
					break;
					
					case XMLStreamConstants.CHARACTERS:
						if (xmlr.getText().trim().length() > 0) {
							String text=xmlr.getText();						
							switch(tagCorrente) {
							case "nome":
								elenco.get(elenco.size()-1).setNome(text);
							break;
							case "cognome":
								elenco.get(elenco.size()-1).setCognome(text);
							break;
							case "sesso":
								elenco.get(elenco.size()-1).setSesso(text);
							break;
							case "comune_nascita":
								elenco.get(elenco.size()-1).setLuogoNascita(text);
							break;
							case "data_nascita":
								elenco.get(elenco.size()-1).setDataNascita(text);
								elenco.get(elenco.size()-1).setCf();
							break;
							}
						}						
					break;
				}
				xmlr.next();
				}
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("\nCaricamento completato!");
		return elenco;
	}//fine metodo
	
	//LEGGI I CODICI FISCALI DAL FILE CODICIFISCALI.XML
	public static ArrayList<CodFiscale> leggiCodiciFisc(String filename){
		String tagCorrente="";
		ArrayList<CodFiscale>elenco = new ArrayList<CodFiscale>();
		
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader(filename, new FileInputStream(filename));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
		try {
			while (xmlr.hasNext()){ 
				
				switch (xmlr.getEventType()) { 
					case XMLStreamConstants.START_DOCUMENT: 
						System.out.println("Start Read Doc " + filename); 
						System.out.println("\nCaricamento in corso..."); 
					break;
					
					case XMLStreamConstants.START_ELEMENT: 
						
						if(xmlr.getLocalName().equals("codice")) {
							elenco.add(new CodFiscale());
						}
						tagCorrente=xmlr.getLocalName();
					break;
					case XMLStreamConstants.CHARACTERS:
						if (xmlr.getText().trim().length() > 0) {
							String text=xmlr.getText();						
							switch(tagCorrente) {
								case "codice":
									elenco.get(elenco.size()-1).setCodFiscale(text);
								break;
							
							}
						}						
					break;
				}
				xmlr.next();
				}
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("\nCaricamento completato!");
		return elenco;
	}

}
