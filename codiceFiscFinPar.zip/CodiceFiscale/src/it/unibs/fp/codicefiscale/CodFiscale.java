package it.unibs.fp.codicefiscale;

import java.io.FileInputStream;
import java.util.*;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class CodFiscale {
	
	private String cod;
	
	public String getCodFiscale() {
		return cod;
	}

	public void setCodFiscale(String codFiscale) {
		this.cod = codFiscale;
	}
	
	public CodFiscale() {};
	
	public CodFiscale(String cod) {
		this.cod=cod;
	};
	
	public CodFiscale(String nome, String cognome, String sesso, String dataNascita, String luogoNascita){
		String cf="";
		//GENERAZIONE 3 CARATTERI NOME
		cf+=generaCognome(cognome);
		//GENERAZIONE 3 CARATTERI COGNOME
		cf+=generaNome(nome);
		//GENERAZIONE 2 CARATTERI ANNO
		cf+=dataNascita.substring(2,4);
		//GENERAZIONE 1 CARATTERE MESE
		cf+=mese(dataNascita.substring(5,7));
		//GENERAZIONE 2 CARATTERI GIORNO
		cf+=generaGiorno(sesso,dataNascita);
		//GENERAZIONE LUOGO
		cf+=generaLuogo(luogoNascita);
		//GENERAZIONE CARATTERE DI CONTROLLO
		cf+=generaCarattereContr(cf);
		this.cod=cf;
	}
	
	private char generaCarattereContr(String cf) {
		
		Map<Character, Integer> mapDisp = new HashMap<Character, Integer>();
		Map<Character, Integer> mapPari = new HashMap<Character, Integer>();
		Map<Integer, Character> resti = new HashMap<Integer, Character>();
		mapDisp.put('0', 1);
		mapDisp.put('1', 0);
		mapDisp.put('2', 5);
		mapDisp.put('3', 7);
		mapDisp.put('4', 9);
		mapDisp.put('5', 13);
		mapDisp.put('6', 15);
		mapDisp.put('7', 17);
		mapDisp.put('8', 19);
		mapDisp.put('9', 21);
		mapDisp.put('A', 1);
		mapDisp.put('B', 0);
		mapDisp.put('C', 5);
		mapDisp.put('D', 7);
		mapDisp.put('E', 9);
		mapDisp.put('F', 13);
		mapDisp.put('G', 15);
		mapDisp.put('H', 17);
		mapDisp.put('I', 19);
		mapDisp.put('J', 21);
		mapDisp.put('K', 2);
		mapDisp.put('L', 4);
		mapDisp.put('M', 18);
		mapDisp.put('N', 20);
		mapDisp.put('O', 11);
		mapDisp.put('P', 3);
		mapDisp.put('Q', 6);
		mapDisp.put('R', 8);
		mapDisp.put('S', 12);
		mapDisp.put('T', 14);
		mapDisp.put('U', 16);
		mapDisp.put('V', 10);
		mapDisp.put('W', 22);
		mapDisp.put('X', 25);
		mapDisp.put('Y', 24);
		mapDisp.put('Z', 23);
		
		mapPari.put('0', 0);
		mapPari.put('1', 1);
		mapPari.put('2', 2);
		mapPari.put('3', 3);
		mapPari.put('4', 4);
		mapPari.put('5', 5);
		mapPari.put('6', 6);
		mapPari.put('7', 7);
		mapPari.put('8', 8);
		mapPari.put('9', 9);
		mapPari.put('A', 0);
		mapPari.put('B', 1);
		mapPari.put('C', 2);
		mapPari.put('D', 3);
		mapPari.put('E', 4);
		mapPari.put('F', 5);
		mapPari.put('G', 6);
		mapPari.put('H', 7);
		mapPari.put('I', 8);
		mapPari.put('J', 9);
		mapPari.put('K', 10);
		mapPari.put('L', 11);
		mapPari.put('M', 12);
		mapPari.put('N', 13);
		mapPari.put('O', 14);
		mapPari.put('P', 15);
		mapPari.put('Q', 16);
		mapPari.put('R', 17);
		mapPari.put('S', 18);
		mapPari.put('T', 19);
		mapPari.put('U', 20);
		mapPari.put('V', 21);
		mapPari.put('W', 22);
		mapPari.put('X', 23);
		mapPari.put('Y', 24);
		mapPari.put('Z', 25);
		
		resti.put(0, 'A');
		resti.put(1, 'B');
		resti.put(2, 'C');
		resti.put(3, 'D');
		resti.put(4, 'E');
		resti.put(5, 'F');
		resti.put(6, 'G');
		resti.put(7, 'H');
		resti.put(8, 'I');
		resti.put(9, 'J');
		resti.put(10, 'K');
		resti.put(11, 'L');
		resti.put(12, 'M');
		resti.put(13, 'N');
		resti.put(14, 'O');
		resti.put(15, 'P');
		resti.put(16, 'Q');
		resti.put(17, 'R');
		resti.put(18, 'S');
		resti.put(19, 'T');
		resti.put(20, 'U');
		resti.put(21, 'V');
		resti.put(22, 'W');
		resti.put(23, 'X');
		resti.put(24, 'Y');
		resti.put(25, 'Z');
		
		int tot=0;
		for(int i=0; i<cf.length(); i++) {
			if(i%2==1) {
				tot+=mapPari.get(cf.charAt(i));
			}else {
				tot+=mapDisp.get(cf.charAt(i));
			}
		}
		char lettera=resti.get(tot%26);
		return lettera;
	}

	private String generaGiorno(String sesso,String dataNascita) {
		String ris="";
		if(sesso.equalsIgnoreCase("M")) {
			ris+=dataNascita.substring(8,10);
		}else {
			ris+=numGiornoRagazze(dataNascita.substring(8,10));	
		}
		return ris;
	}
	
	private String generaCognome(String cog) {
		String cognome="";
		int cons=0;
		
		//GENERAZIONE COGNOME
		for(int i=0;i<cog.length();i++) {
			if(!isVocale(cog.charAt(i))) {
				cons++;
			}
		}
		
		if(cog.length()<3) {
			cognome+=cog;
			
			while(cognome.length()<3) {
				cognome+="X";
			}
		}else if(cons<3){
			for(int i=0;i<cog.length();i++) {
				if(!isVocale(cog.charAt(i)) ) {
					cognome+=cog.charAt(i);
				}
			}
			
			for(int i=0;i<cog.length();i++) {
				if(isVocale(cog.charAt(i)) && cognome.length()<3) {
					cognome+=cog.charAt(i);
				}
			}
			
		}else {
			for(int i=0;i<cog.length();i++) {
				if(!isVocale(cog.charAt(i)) && cognome.length()<3) {
					cognome+=cog.charAt(i);
				}
			}
		}

		return cognome;
	}
	private String generaNome(String nomee) {
		String nome="";
		int cons=0;
		
		//GENERAZIONE NOME
		for(int i=0;i<nomee.length();i++) {
			if(!isVocale(nomee.charAt(i))) {
				cons++;
			}
		}
		
		if(nomee.length()<3) {
			nome+=nomee;
			
			while(nome.length()<3) {
				nome+="X";
			}
		}else if(cons==3) {
			for(int i=0;i<nomee.length();i++) {
				if(!isVocale(nomee.charAt(i)) && nome.length()<3) {
					nome+=nomee.charAt(i);
				}
			}
		}else if(cons<3){
			for(int i=0;i<nomee.length();i++) {
				if(!isVocale(nomee.charAt(i)) ) {
					nome+=nomee.charAt(i);
				}
			}
			
			for(int i=0;i<nomee.length();i++) {
				if(isVocale(nomee.charAt(i)) && nome.length()<3) {
					nome+=nomee.charAt(i);
				}
			}
			
		}else {
			int c=0;
			for(int i=0;i<nomee.length();i++) {
				if(!isVocale(nomee.charAt(i)) && nome.length()<3) {
					if(c==1) {
						c++;
					}else {
						nome+=nomee.charAt(i);
						c++;
					}
				}
			}
		}
		
		return nome;
	}
	private boolean isVocale(char lettera){
		boolean ris=false;
			switch(lettera) {
			case 'A':
				ris=true;
			break;
			case 'E':
				ris=true;
			break;
				
			case 'I':
				ris=true;
			break;
			
			case 'O':
				ris=true;
			break;
				
			case 'U':
				ris=true;
			break;	
			}
		return ris;
	}
	private String mese(String s) {
       switch(s) {
		case "01":
			return "A";
		case "02":
			return "B";
			
		case "03":
			return "C";
			
		case "04":
			return "D";
			
		case "05":
			return "E";
			
		case "06":
			return "H";
			
		case "07":
			return "L";
			
		case "08":
			return "M";
						
		case "09":
			return "P";
			
		case "10":
			return "R";
			
		case "11":
			return "S";
			
		case "12":
			return "T";
					
		}
	return "Non � entrato nei altri case";//se non mi entra nei altri casi
	}
	private String numGiornoRagazze(String s) {
		//numeri di giorni per le ragazze
		
		if(Integer.parseInt(s)<41) {
			
		}
		
		
		switch(s) {
		case "01":
			return "41";
		case "02":
			return "42";
			
		case "03":
			return "43";
			
		case "04":
			return "44";
			
		case "05":
			return "45";
			
		case "06":
			return "46";
			
		case "07":
			return "47";
			
		case "08":
			return "48";
						
		case "09":
			return "49";
			
		case "10":
			return "50";
			
		case "11":
			return "51";
			
		case "12":
			return "52";
		case "13":
			return "53";
		case "14":
			return "54";
			
		case "15":
			return "55";
			
		case "16":
			return "56";
			
		case "17":
			return "57";
			
		case "18":
			return "58";
			
		case "19":
			return "59";
			
		case "20":
			return "60";
						
		case "21":
			return "61";
			
		case "22":
			return "62";
			
		case "23":
			return "63";
			
		case "24":
			return "64";	
		case "25":
			return "65";
			
		case "26":
			return "66";
			
		case "27":
			return "67";
			
		case "28":
			return "68";
						
		case "29":
			return "69";
			
		case "30":
			return "70";
			
		case "31":
			return "71";		
		
		}
		
	return "Non � stato trovato";
		
	}
	
	private String generaLuogo(String luogo)  {
		String ris="";
		ArrayList<Comune>comuni=new ArrayList<Comune>();
		
		comuni=Comune.leggiComuni();
		
		/*String ris="",filename="comuni.xml",tagCorrente="";
		ArrayList<Comune>comuni=new ArrayList<Comune>();
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader(filename, new FileInputStream(filename));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
		try {
			while (xmlr.hasNext()){ // continua a leggere finch� ha eventi a disposizione
				switch (xmlr.getEventType()) { // switch sul tipo di evento
					case XMLStreamConstants.START_DOCUMENT: // inizio del documento: stampa che inizia il documento 
					break;
					
					case XMLStreamConstants.START_ELEMENT: // inizio di un elemento: stampa il nome del tag e i suoi attributi
						if(xmlr.getLocalName().equals("comune")) {
							comuni.add(new Comune());
						}
						tagCorrente=xmlr.getLocalName();
						
					break;
					case XMLStreamConstants.END_ELEMENT: // fine di un elemento: stampa il nome del tag chiuso
					break;
					
					case XMLStreamConstants.COMMENT:	
					break;
					
					case XMLStreamConstants.CHARACTERS: // content all�interno di un elemento: stampa il testo
						if (xmlr.getText().trim().length() > 0) {
							String text=xmlr.getText();						
							switch(tagCorrente) {
							case "nome":
								comuni.get(comuni.size()-1).setNome(text);
							break;
							case "codice":
								comuni.get(comuni.size()-1).setCodice(text);
							break;
							}
						}						
					break;
				}
				xmlr.next();
				}
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
			for(int i=0;i<comuni.size();i++) {
				if(luogo.equals(comuni.get(i).getNome())) {
					ris+=comuni.get(i).getCodice();
				}
			}
		return ris;
	}
	
	@Override
	public String toString() {
		return "\nCodice fiscale: "+cod;
	}
}