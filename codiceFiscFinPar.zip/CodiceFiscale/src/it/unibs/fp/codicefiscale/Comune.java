package it.unibs.fp.codicefiscale;

import java.io.FileInputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class Comune {
	private String nome;
	private String codice;
	
	public Comune() {};
	
	public Comune(String nome, String codice) {
		super();
		this.nome = nome;
		this.codice = codice;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodice() {
		return codice;
	}
	public void setCodice(String codice) {
		this.codice = codice;
	}
	
	public static ArrayList<Comune> leggiComuni()  {
		String filename="comuni.xml",tagCorrente="";
		ArrayList<Comune>comuni=new ArrayList<Comune>();
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader(filename, new FileInputStream(filename));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
		try {
			while (xmlr.hasNext()){ // continua a leggere finch� ha eventi a disposizione
				switch (xmlr.getEventType()) { // switch sul tipo di evento
					case XMLStreamConstants.START_DOCUMENT: // inizio del documento: stampa che inizia il documento 
					break;
					
					case XMLStreamConstants.START_ELEMENT: // inizio di un elemento: stampa il nome del tag e i suoi attributi
						if(xmlr.getLocalName().equals("comune")) {
							comuni.add(new Comune());
						}
						tagCorrente=xmlr.getLocalName();
						
					break;
					case XMLStreamConstants.END_ELEMENT: // fine di un elemento: stampa il nome del tag chiuso
					break;
					
					case XMLStreamConstants.COMMENT:	
					break;
					
					case XMLStreamConstants.CHARACTERS: // content all�interno di un elemento: stampa il testo
						if (xmlr.getText().trim().length() > 0) {
							String text=xmlr.getText();						
							switch(tagCorrente) {
							case "nome":
								comuni.get(comuni.size()-1).setNome(text);
							break;
							case "codice":
								comuni.get(comuni.size()-1).setCodice(text);
							break;
							}
						}						
					break;
				}
				xmlr.next();
				}
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return comuni;
	}
	
	
	
	
}
